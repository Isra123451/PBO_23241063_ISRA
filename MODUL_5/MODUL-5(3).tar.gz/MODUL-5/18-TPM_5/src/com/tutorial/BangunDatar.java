package com.tutorial;

public class BangunDatar {
    public float luas;
    public float keliling;
}

